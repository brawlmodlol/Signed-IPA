Please Dont Ask For P12
Files with ❌ Indicates Revoked